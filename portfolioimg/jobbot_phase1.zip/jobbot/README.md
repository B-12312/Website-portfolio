# Phase 1: Resume tailoring
1. pip install -r requirements.txt
2. Install Tectonic: https://tectonic-typesetting.github.io/en-us/install.html
3. export ANTHROPIC_API_KEY=...
4. Fill profile.yaml with ALL your real bullets/skills.
5. Paste your Overleaf .tex into templates/resume.tex.j2 and replace content with << >> / <% %> placeholders.
6. Save a job description into job.txt, then:
   python run_tailor.py job.txt --company Acme --role "Backend Engineer"
