"""Usage: python run_tailor.py job.txt --company Acme --role "Backend Engineer" """
import argparse, re, yaml
from pathlib import Path
from src import tailor, checks, latex

ap = argparse.ArgumentParser()
ap.add_argument("job_file"); ap.add_argument("--company", required=True)
ap.add_argument("--role", required=True)
a = ap.parse_args()

profile = yaml.safe_load(open("profile.yaml"))
jd = Path(a.job_file).read_text()
name = re.sub(r"\W+", "_", f"{profile['personal']['name']}_{a.role}_{a.company}")
out = Path("out") / f"{name}.pdf"

feedback = ""
for attempt in range(3):
    sel = tailor.select_content(profile, jd, feedback)
    errs = checks.validate(profile, sel)
    if errs:
        feedback = "\n".join(errs); print("Retry:", feedback); continue
    src = latex.render("templates", "resume.tex.j2", tailor.build_context(profile, sel))
    latex.compile_pdf(src, out)
    n = latex.page_count(out)
    if n > 1:
        feedback = f"Resume is {n} pages. Cut content to fit 1 page."; print(feedback); continue
    print("OK ->", out); break
else:
    print("FAILED: send this job to manual review.")
