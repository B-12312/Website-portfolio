import re

_NUM = re.compile(r"\d+(?:\.\d+)?")

def _all_skills(profile):
    return {s.lower() for items in profile["skills"].values() for s in items}

def _bullet_map(profile):
    m = {}
    for sec in ("experience", "projects"):
        for e in profile.get(sec, []):
            for b in e["bullets"]:
                m[b["id"]] = b["text"]
    return m

def validate(profile: dict, sel: dict) -> list[str]:
    """Return a list of problems. Empty list = safe to use."""
    errs, bmap, known = [], _bullet_map(profile), _all_skills(profile)

    for cat, items in sel.get("skills", {}).items():
        for s in items:
            if s.lower() not in known:
                errs.append(f"Skill not in master bank: {s}")

    entries = {**(sel.get("experience") or {}), **(sel.get("projects") or {})}
    for eid, bullets in entries.items():
        for b in bullets:
            orig = bmap.get(b["id"])
            if orig is None:
                errs.append(f"Unknown bullet id: {b['id']}")
                continue
            new = b.get("text") or orig
            if set(_NUM.findall(new)) - set(_NUM.findall(orig)):
                errs.append(f"Invented number in {b['id']}: {new}")
    return errs
