import json, os, re
import anthropic

MODEL = "claude-sonnet-5"

SYSTEM = """You tailor a resume to a job description.
You are given a MASTER BANK of true facts (a Java/backend trainee's real resume). Rules:
- Only use skills and bullets that exist in the bank. Never invent skills, tools, employers, numbers or achievements.
- You may reorder, drop, and lightly reword bullets to mirror the job's keywords, but keep every number identical.
- Always include the "quest" experience entry (it's the only job). Pick the strongest 2-4 of its bullets.
- Pick the 2-3 projects most relevant to the job (by id), each with 1-2 bullets.
- Write a 2-sentence summary based on summary_base, angled toward this job, without inventing experience.
- Keep it to ONE page.
- Reply with JSON ONLY, no markdown fences, in this exact shape:
{"summary": "2 sentences",
 "skills": {"Category": ["skill", ...]},
 "experience": {"quest": [{"id": "<bullet_id>", "text": "<reworded or original>"}]},
 "projects": {"<project_id>": [{"id": "<bullet_id>", "text": "..."}]}}"""

def _client():
    return anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

def select_content(profile: dict, job_desc: str, feedback: str = "") -> dict:
    user = f"MASTER BANK:\n{json.dumps(profile, indent=1)}\n\nJOB DESCRIPTION:\n{job_desc}"
    if feedback:
        user += f"\n\nYour previous answer had problems, fix them:\n{feedback}"
    msg = _client().messages.create(
        model=MODEL, max_tokens=2000, system=SYSTEM,
        messages=[{"role": "user", "content": user}])
    text = msg.content[0].text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text).strip()
    return json.loads(text)

def build_context(profile: dict, sel: dict) -> dict:
    bmap = {b["id"]: b["text"] for sec in ("experience", "projects")
            for e in profile[sec] for b in e["bullets"]}

    def pick(entries, chosen):
        out = []
        for e in entries:
            if e["id"] in chosen:
                bl = [b.get("text") or bmap[b["id"]] for b in chosen[e["id"]]]
                out.append({**e, "bullets": bl})
        return out

    return {"p": profile["personal"], "summary": sel["summary"],
            "skills": sel["skills"],
            "experience": pick(profile["experience"], sel.get("experience", {})),
            "projects": pick(profile.get("projects", []), sel.get("projects", {})),
            "education": profile["education"],
            "certifications": profile.get("certifications", []),
            "soft_skills": profile.get("soft_skills", []),
            "achievements": profile.get("achievements", []),
            "languages_spoken": profile.get("languages_spoken", [])}
