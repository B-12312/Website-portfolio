import re, shutil, subprocess, tempfile
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from pypdf import PdfReader

_MAP = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
        "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
_RE = re.compile("|".join(re.escape(k) for k in _MAP))

def tex(s) -> str:
    """Escape LaTeX special characters (single pass, so no double-escaping)."""
    return _RE.sub(lambda m: _MAP[m.group()], str(s))

def render(template_dir: str, template: str, ctx: dict) -> str:
    env = Environment(
        loader=FileSystemLoader(template_dir),
        block_start_string="<%", block_end_string="%>",
        variable_start_string="<<", variable_end_string=">>",
        comment_start_string="<#", comment_end_string="#>",
        trim_blocks=True, lstrip_blocks=True, autoescape=False)
    env.filters["tex"] = tex
    return env.get_template(template).render(**ctx)

def compile_pdf(tex_source: str, out_pdf: Path) -> Path:
    """Compile with Tectonic (https://tectonic-typesetting.github.io)."""
    if not shutil.which("tectonic"):
        raise RuntimeError("Install tectonic first (see README).")
    with tempfile.TemporaryDirectory() as d:
        src = Path(d) / "resume.tex"
        src.write_text(tex_source, encoding="utf-8")
        r = subprocess.run(["tectonic", str(src)], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("LaTeX failed:\n" + r.stderr[-1500:])
        out_pdf.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(Path(d) / "resume.pdf", out_pdf)
    return out_pdf

def page_count(pdf: Path) -> int:
    return len(PdfReader(str(pdf)).pages)
